package Aplicacao;

public class Array {
	int[] a = new int[10], b = new int[10], c = new int[10];
	int soma, i;
	
	public int somaA(int[] a) {
		soma = 0;
		for(i=0; i<a.length; i++) {
			soma+=a[i];
		}
		return soma;
	}
	public int[] somaAB(int a[], int b[]) {
		for(i=0;i<c.length;i++) {
			c[i]=a[i]+b[i];
		}
		return c;
	}
}
