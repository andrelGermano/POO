package Visao;
import java.util.Scanner;

import Aplicacao.Array;

public class Principal {

	public static void main(String[] args) {
		int tam=10;
		int i;
		int[] a = new int[tam], b = new int[tam], c = new int[tam];
		Array array = new Array();
		var r = new Scanner(System.in);
		
		System.out.println("Lendo A...");
		for(i=0; i<a.length; i++) {
			System.out.println("A[" + i + "]: ");
			a[i]=r.nextInt();
		}
		System.out.println("Lendo B...");
		for(i=0; i<a.length; i++) {
			System.out.println("B[" + i + "]: ");
			b[i]=r.nextInt();
		}
		
		System.out.println("Soma dos elementos de A: " + array.somaA(a));
		
		System.out.println("Vetor C contendo soma dos elementos de A e B:");
		c=array.somaAB(a, b);
		for(i=0;i<c.length; i++) {
			System.out.println("C[" + i + "]: " + c[i]);
		}
		
	}

}
